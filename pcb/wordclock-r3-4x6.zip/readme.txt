wordclock-r3-4x6
================
Board Material: FR-4
Hole Plating: All holes plated through
Board Thickness: 1.6mm

Technical Contact: Randy Glenn, randy@surrealitylabs.com

Top Layer: wordclock-r3-4x6.cmp
Bottom Layer: wordclock-r3-4x6.sol
Solder Mask Top Layer: wordclock-r3-4x6.stc
Solder Mask Bottom Layer: wordclock-r3-4x6.sts
Silkscreen Top Layer: wordclock-r3-4x6.plc
Silkscreen Bottom Layer: wordclock-r3-4x6.pls
Drill file: wordclock-r3-4x6.drd
Board outline: wordclock-r3-4x6.bor